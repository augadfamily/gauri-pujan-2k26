JYESHTHA GAURI PUJAN 2026 — AUGAD PARIVAAR
================================================

A mobile-first single-scrolling invitation website created from the supplied Gauri photographs,
8 supplied videos, gold devotional artwork, and the supplied Navasachi Gauri Mazi audio.

Open index.html in a modern browser. The site is static and needs no server.

Notes:
- Music starts only after the visitor presses "आमंत्रण उघडा".
- Play/pause remains available while scrolling.
- The 18 September main pujan time is 7:00 PM, following the final event data.
- Google Maps button opens a search for the supplied address.
- No phone, WhatsApp, email, RSVP, aarti, donation, or invented program details were added.
