JYESHTHA GAURI PUJAN 2026 — FIXED GITHUB PAGES DEPLOYMENT

Repository:
augadfamily/gauri-pujan-2k26

WHAT WAS FIXED
--------------
The previous gauri-site.zip contained an extra top-level folder:
  Jyeshtha_Gauri_Pujan_2026_Website/index.html

GitHub Pages requires index.html at the top level of the deployed artifact.
This package contains a corrected gauri-site.zip whose root is:
  index.html
  assets/
  .nojekyll

The deployment workflow also validates that site/index.html exists before
uploading the Pages artifact, so this specific 404 cannot silently recur.

FILES TO UPLOAD TO GITHUB
-------------------------
1. gauri-site.zip
   Replace the existing gauri-site.zip in the repository.

2. .github/workflows/deploy-gauri-pages.yml
   Replace the existing deployment workflow with this file.

IMPORTANT
---------
Do NOT change GitHub Settings > Pages. Keep:
  Source = GitHub Actions

After committing both files to main, GitHub Actions should automatically
run the deployment.

EXPECTED SITE
-------------
https://augadfamily.github.io/gauri-pujan-2k26/

The workflow uses current GitHub Pages actions and checkout@v6, and includes
a root-index validation before deployment.
