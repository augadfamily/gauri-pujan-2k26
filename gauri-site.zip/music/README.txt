Place the supplied audio file here with this exact filename:
navasachi-gauri-mazi-background.mp3

The website starts playback after the visitor taps “आमंत्रण उघडा”.
The floating circular controls allow pause/play and full stop.
